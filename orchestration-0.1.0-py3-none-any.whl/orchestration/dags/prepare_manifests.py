from __future__ import annotations
from airflow.decorators import dag, task, task_group
from datetime import datetime
from pathlib import Path
import sys
from typing import TYPE_CHECKING
from airflow.utils.helpers import chain
from airflow.operators.python import get_current_context
from orchestration import QRCP
from airflow.providers.google.cloud.transfers.sftp_to_gcs import SFTPToGCSOperator
from airflow.providers.google.suite.hooks.sheets import GSheetsHook
from airflow.providers.google.cloud.operators.gcs import GCSListObjectsOperator
from returns.result import Success, Failure
from typing import Literal
from urllib.parse import urljoin, urlparse
import logging
from ftplib import FTP
import polars as pl

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from typing import Any
RUN_DATE = datetime.today()

config_file_path = "/config/config.yaml"


@dag(start_date=RUN_DATE)
def gentropy(config_file_path: str = config_file_path) -> None:
    @task_group(group_id="process_config")
    def process_config(config_file_path: str = config_file_path) -> None:
        @task.short_circuit()
        def get_config_path(config_file_path: str) -> bool:
            logger.info("Running Gentropy pipeline with %s", config_file_path)
            config_exists = Path(config_file_path).exists()
            logger.info("Checking if config file exists...")
            if not config_exists:
                logging.error(
                    f"Config at {str(config_file_path)} was not found")
                sys.exit(1)
            logger.info("Config file exists")
            return config_exists

        @task.python(task_id="read_config")
        def parse_config_file(config_file_path: str) -> dict[str, Any]:
            # perform validation by the QRCP model once.
            logger.info("Validating configuration file")
            return QRCP.from_file(config_file_path).serialize()

        chain(get_config_path(config_file_path),
              parse_config_file(config_file_path))

    @task(task_id="pull_gentropy_dag_params")
    def pull_gentropy_dag_params() -> dict[str, Any]:
        """Generic Method to pull the config from the parser task

        Returns:
            dict[str, str]: config
        """
        ti = get_current_context()["ti"]
        logger.info("Pulling config file from read_config task")
        config = ti.xcom_pull(task_ids="process_config.read_config")
        logger.info("Deserializing config with QRCP")
        config = QRCP.deserialize(config)
        logger.info("Extracting gentropy_dag paramters from config")
        gentropy_params = config.get_gentropy_dag_params()

        match gentropy_params:
            case Success(params):
                logging.info("Gentropy params: %s", params)
                gentropy_params = params
            case Failure(msg):
                logging.error("Add the Gentropy section to the DAGS config")
                raise ValueError(msg)
        return gentropy_params

    @task(task_id="pull_gwas_catalog_manifest")
    def pull_gwas_catalog_manifest(task_id) -> pl.DataFrame:
        """Pull manifest to the next tasks"""
        ti = get_current_context()["ti"]
        logger.info("Pulling GWAS Catalog curation manifest")
        manifest = ti.xcom_pull(task_id)
        print(manifest)

    @task_group(group_id="prepare_manifest")
    def prepare_manifest(gentropy_params: dict[str, Any]) -> None:
        """ "Prepare manifests for the curration update of GWAS Catalog"""

        @task(task_id="prepare_gwas_catalog_manifest_paths")
        def prepare_gwas_catalog_manifest_paths(
            gentropy_params: dict[str, Any],
        ) -> list[dict[str, Any]]:
            transfer_objects = []
            for input_file, output_file in zip(
                gentropy_params["gwas_catalog_manifest_files_ftp"],
                gentropy_params["gwas_catalog_manifest_files_gcs"],
            ):
                transfer_object = {
                    "task_id": f"transfer_{input_file}_to_gcs",
                    "source_path": urljoin(
                        gentropy_params["gwas_catalog_release_ftp"],
                        input_file,
                    ),
                    "destination_bucket": gentropy_params["gwas_catalog_data_bucket"],
                    "destination_path": output_file,
                }
                logger.info("transfer_object: %s", transfer_object)
                transfer_objects.append(transfer_object)
            return transfer_objects

        @task_group(group_id="sync_gwas_catalog_manifests")
        def sync_gwas_catalog_manifests(
            manifest_transfer_objects: list[dict[str, str]],
        ) -> None:
            SFTPToGCSOperator.expand_kwargs(manifest_transfer_objects)

        @task(task_id="sync_curation_manifest")
        def consume_manifest_file(gentropy_params: dict[str, str]) -> pl.DataFrame:
            """Sync curation manifest from path given by config to the bucket given by config

            Args:
                config (dict[str, str]): gentropy configuration object
            """
            manifest_url = gentropy_params["manual_curation_manifest_gh"]
            logging.info("Reading initial manifest from %s", manifest_url)
            manifest = pl.read_csv(
                manifest_url, has_header=True, separator="\t")
            return manifest

        # steps are independent
        manifest_transfer_objects = prepare_gwas_catalog_manifest_paths(
            gentropy_params)
        [
            sync_gwas_catalog_manifests(manifest_transfer_objects),
            consume_manifest_file(gentropy_params),
        ]

    gentropy_params = pull_gentropy_dag_params()
    manifest = pull_gwas_catalog_manifest(
        "prepare_manifest.consume_manifest_file")

    chain(
        process_config(config_file_path),
        gentropy_params,
        prepare_manifest(gentropy_params),
        manifest,
    )


gentropy_dag = gentropy()
